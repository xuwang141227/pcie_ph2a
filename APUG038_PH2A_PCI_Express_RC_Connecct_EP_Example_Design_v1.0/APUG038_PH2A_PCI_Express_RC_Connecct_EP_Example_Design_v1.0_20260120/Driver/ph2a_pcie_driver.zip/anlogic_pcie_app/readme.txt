PCI BAR 32位寄存器寄存器操作

bar_id 小于6， offset 必须试4的整数倍(4字节对齐）
1）
read
./pci_bar bar_id offset
ex:
./pci_bar 0 0x0
./pci_bar 0 0x4
2）
write
./pci_bar bar_id offset wrdata
ex:
./pci_bar 0 0x0 0x12345678
./pci_bar 0 0x4 0x55aa1234