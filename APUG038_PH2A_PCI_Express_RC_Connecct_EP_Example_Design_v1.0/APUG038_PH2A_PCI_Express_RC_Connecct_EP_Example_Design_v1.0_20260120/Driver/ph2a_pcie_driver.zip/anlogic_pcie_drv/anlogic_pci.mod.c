#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xf704969, "module_layout" },
	{ 0x4b4af741, "kmem_cache_destroy" },
	{ 0xc946dda0, "cdev_del" },
	{ 0xd731cdd9, "kmalloc_caches" },
	{ 0x71dc9728, "pci_write_config_dword" },
	{ 0x2d725fd4, "cdev_init" },
	{ 0x95d9e1d1, "pci_write_config_word" },
	{ 0x46cf10eb, "cachemode2protval" },
	{ 0xe9c2ad91, "dma_set_mask" },
	{ 0x35c64e5d, "pcie_set_readrq" },
	{ 0xa92ec74, "boot_cpu_data" },
	{ 0x8de7b894, "pci_disable_device" },
	{ 0xfec78051, "pci_disable_msix" },
	{ 0x82e7bb9c, "device_destroy" },
	{ 0x15a66331, "kobject_set_name" },
	{ 0xfbc3773, "pci_release_regions" },
	{ 0x782ce0d0, "pcie_capability_clear_and_set_word" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x1f87d038, "dma_set_coherent_mask" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x303004cd, "pci_set_master" },
	{ 0xdf2a2797, "pci_restore_state" },
	{ 0x6535b752, "pci_iounmap" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xb3c9b55c, "pci_read_config_word" },
	{ 0xefc94da8, "device_create" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x7eb2bdfa, "pci_find_capability" },
	{ 0xc378cea7, "cdev_add" },
	{ 0x800473f, "__cond_resched" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0x1000e51, "schedule" },
	{ 0x92997ed8, "_printk" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x81c6ed04, "pci_read_config_dword" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x8754a2ac, "pci_unregister_driver" },
	{ 0x7c797b6, "kmem_cache_alloc_trace" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xa8b5e7f0, "kmem_cache_create" },
	{ 0xcee60703, "pci_irq_vector" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x37a0cba, "kfree" },
	{ 0x6943d575, "remap_pfn_range" },
	{ 0xe3623b5c, "pci_request_regions" },
	{ 0xcd2f8f17, "pci_disable_msi" },
	{ 0x76c2092d, "__pci_register_driver" },
	{ 0x933c4a18, "class_destroy" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xdf6ddad, "pci_iomap" },
	{ 0x27fd16f1, "pci_enable_device_mem" },
	{ 0x4a453f53, "iowrite32" },
	{ 0xe9b2e30d, "pci_enable_device" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x325cb5cb, "__class_create" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0xa78af5f3, "ioread32" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xa3171885, "pci_save_state" },
	{ 0x8a35b432, "sme_me_mask" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("pci:v00001EDBd0000ABCDsv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "EFA8474B63278825751B749");
