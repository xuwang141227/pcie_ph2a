/home/ae/桌面/PH2A/legacy_int/anlogic_pcie_drv/anlogic_pci_lib.o /home/ae/桌面/PH2A/legacy_int/anlogic_pcie_drv/anlogic_pci_cdev.o /home/ae/桌面/PH2A/legacy_int/anlogic_pcie_drv/cdev_ctrl.o /home/ae/桌面/PH2A/legacy_int/anlogic_pcie_drv/cdev_events.o /home/ae/桌面/PH2A/legacy_int/anlogic_pcie_drv/anlogic_pci_drv.o

